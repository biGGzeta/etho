API_KEY = 'TU_API_KEY'
API_SECRET = 'TU_API_SECRET'

SYMBOL = 'ETHUSDT'
LEVERAGE = 10

# Grid settings
GRID_RANGE_MIN = 0.06  # 6%
GRID_RANGE_MAX = 0.15  # 15%
MIN_GRID_SPACING = 0.003  # 0.3%
MAX_GRID_SPACING = 0.0075  # 0.75%
ORDER_USDT_SIZE = 10  # Capital por orden (x10 leverage en Futuros)

# Take profit
MIN_PROFIT_THRESHOLD = 0.003  # 0.3%
TP_SPACING_MIN = 0.0003  # 0.03%
TP_SPACING_MAX = 0.0007  # 0.07%

# SL Global
STOP_LOSS_PERCENTAGE = 0.15  # 15%

# Archivo estado
STATE_FILE = 'data/bot_state.json'