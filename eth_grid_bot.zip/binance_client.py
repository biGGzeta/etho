from binance.client import Client
from binance.enums import *
from config import API_KEY, API_SECRET, SYMBOL, LEVERAGE

class BinanceClient:
    def __init__(self):
        self.client = Client(API_KEY, API_SECRET)
        self.futures = self.client.futures

        # Establecer apalancamiento
        self.set_leverage()

    def set_leverage(self):
        try:
            self.futures.change_leverage(symbol=SYMBOL, leverage=LEVERAGE)
        except Exception as e:
            print(f"[ERROR] No se pudo establecer el leverage: {e}")

    def get_balance(self, asset='USDT'):
        balances = self.futures.account()['assets']
        for b in balances:
            if b['asset'] == asset:
                return float(b['availableBalance'])

    def get_position(self):
        positions = self.futures.position_information(symbol=SYMBOL)
        for p in positions:
            if float(p['positionAmt']) != 0:
                return p
        return None